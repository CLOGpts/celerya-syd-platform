/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, GenerateContentResponse, GenerateContentParameters } from "@google/genai";

// Ensure pdfjsLib, XLSX, and mammoth are available from global scope (CDN)
declare const pdfjsLib: any;
declare const XLSX: any;
declare const mammoth: any;

interface ExtractedTableData {
    pageNumber: number; // For PDF page, Excel sheet number, or 1 for other file types
    pageName?: string; // e.g., Excel sheet name
    tables: string[][][]; // Array of tables, each table is array of rows, each row is array of cells
}

// Global state for column filtering
let globalFilterSourceInfo: {
    pageNumber: number;
    tableIndexOnPage: number;
    columnCount: number;
} | null = null;
let globalColumnSelections: boolean[] = [];

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    console.error("API_KEY environment variable not set.");
    alert("API Key is not configured. Please check the console for details.");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

const fileUploadInput = document.getElementById('file-upload') as HTMLInputElement; // Updated ID
const fileNameDisplay = document.getElementById('file-name-display') as HTMLSpanElement;
const statusMessage = document.getElementById('status-message') as HTMLParagraphElement;
const tablesOutput = document.getElementById('tables-output') as HTMLDivElement;
const downloadExcelButton = document.getElementById('download-excel-button') as HTMLButtonElement;
const loadingSpinner = document.getElementById('loading-spinner') as HTMLDivElement;
const filterInfoMessage = document.getElementById('filter-info-message') as HTMLParagraphElement;


let allExtractedTables: ExtractedTableData[] = [];

// --- API Rate Limiting ---
const MAX_AI_REQUESTS_PER_MINUTE = 60;
const AI_REQUEST_WINDOW_MS = 60 * 1000;
let apiCallTimestamps: number[] = [];
// --- End API Rate Limiting ---

function updateStatus(message: string, isLoading: boolean = false) {
    statusMessage.textContent = message;
    loadingSpinner.style.display = isLoading ? 'block' : 'none';
    if (message.toLowerCase().includes("error") || message.toLowerCase().includes("failed") || message.toLowerCase().includes("invalid")) {
        statusMessage.style.color = 'red';
    } else if (message.toLowerCase().includes("warning") || message.toLowerCase().includes("rate limiting")) {
        statusMessage.style.color = '#e67e22'; // Orange for warnings & rate limiting
    }
    else {
        statusMessage.style.color = '#333'; // Default color
    }
}

function resetGlobalFilterState() {
    globalFilterSourceInfo = null;
    globalColumnSelections = [];
    document.querySelectorAll('.global-filter-source-table').forEach(el => el.classList.remove('global-filter-source-table'));
    filterInfoMessage.style.display = 'none';
}

async function handleFileSelect(event: Event) {
    const files = (event.target as HTMLInputElement).files;
    if (!files || files.length === 0) {
        fileNameDisplay.textContent = 'No file selected';
        return;
    }

    const startTime = performance.now();
    const file = files[0];
    fileNameDisplay.textContent = `Selected: ${file.name}`;
    tablesOutput.innerHTML = '<p>Processing file...</p>'; // Clear previous results
    downloadExcelButton.disabled = true;
    resetGlobalFilterState();
    allExtractedTables = [];
    apiCallTimestamps = []; // Reset rate limiter state for new file

    updateStatus(`Processing ${file.name}...`, true);

    try {
        const fileType = file.type;
        const fileName = file.name.toLowerCase();

        if (fileType === 'application/pdf' || fileName.endsWith('.pdf')) {
            await processPdfFile(file);
        } else if (fileType.startsWith('image/')) {
            await processImageFile(file);
        } else if (fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || fileName.endsWith('.docx') ||
                   fileType === 'application/msword' || fileName.endsWith('.doc')) {
            await processWordFile(file);
        } else if (fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || fileName.endsWith('.xlsx') ||
                   fileType === 'application/vnd.ms-excel' || fileName.endsWith('.xls')) {
            await processExcelFile(file);
        } else if (fileType === 'application/json' || fileName.endsWith('.json')) {
            await processJsonFile(file);
        } else if (fileType === 'text/csv' || fileName.endsWith('.csv')) {
            await processCsvFile(file);
        } else if (fileType === 'text/plain' || fileName.endsWith('.txt')) {
            await processTextFile(file);
        } else {
            const endTime = performance.now();
            const durationSeconds = ((endTime - startTime) / 1000).toFixed(2);
            updateStatus(`Error processing in ${durationSeconds}s: Unsupported file type "${fileType || 'unknown'}". Please select a PDF, image, Word, Excel, JSON, CSV, or TXT file.`, false);
            fileNameDisplay.textContent = 'Invalid file type.';
            fileUploadInput.value = ''; // Reset file input
            return;
        }

        displayExtractedTables();
        const endTime = performance.now();
        const durationSeconds = ((endTime - startTime) / 1000).toFixed(2);

        if (allExtractedTables.some(pageData => pageData.tables.length > 0)) {
            downloadExcelButton.disabled = false;
            updateStatus(`Processing complete in ${durationSeconds}s. Review tables, select columns, and download Excel.`, false);
            if (globalFilterSourceInfo) { // Show filter info if a source was identified
                 filterInfoMessage.style.display = 'block';
            }
        } else {
            updateStatus(`Processing complete in ${durationSeconds}s. No tables found or extracted.`, false);
            tablesOutput.innerHTML = '<p>No tables were detected or extracted from the file.</p>';
        }

    } catch (error) {
        const endTime = performance.now();
        const durationSeconds = ((endTime - startTime) / 1000).toFixed(2);
        console.error('Error processing file:', error);
        updateStatus(`Error processing file after ${durationSeconds}s: ${error instanceof Error ? error.message : String(error)}`, false);
        tablesOutput.innerHTML = '<p>An error occurred while processing the file.</p>';
    }
}

async function ensureApiRateLimit() {
    let now = Date.now();
    // Remove timestamps older than the window
    apiCallTimestamps = apiCallTimestamps.filter(timestamp => now - timestamp < AI_REQUEST_WINDOW_MS);

    if (apiCallTimestamps.length >= MAX_AI_REQUESTS_PER_MINUTE) {
        // Oldest call is at the beginning of the sorted array
        const oldestCallInWindowTimestamp = apiCallTimestamps[0];
        const timeToWait = (oldestCallInWindowTimestamp + AI_REQUEST_WINDOW_MS) - now;
        
        if (timeToWait > 0) {
            const waitSeconds = (timeToWait / 1000).toFixed(1);
            console.warn(`Rate limiting AI calls. Waiting for ${waitSeconds}s.`);
            updateStatus(`Rate limiting AI calls to maintain API health (wait: ${waitSeconds}s). Processing continues...`, true);
            await new Promise(resolve => setTimeout(resolve, timeToWait));
            
            // After waiting, update 'now' and re-filter timestamps as more time has passed
            now = Date.now();
            apiCallTimestamps = apiCallTimestamps.filter(timestamp => now - timestamp < AI_REQUEST_WINDOW_MS);
        }
    }
    // Add current call's timestamp
    apiCallTimestamps.push(now);
    // Keep timestamps sorted (oldest first)
    apiCallTimestamps.sort((a, b) => a - b);
}


async function processPdfFile(file: File) {
    updateStatus('Loading PDF...', true);
    const arrayBuffer = await file.arrayBuffer();
    const pdfDocument = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const numPages = pdfDocument.numPages;
    
    const CONCURRENCY_LIMIT = 10; // Max 10 parallel page processing tasks.
    updateStatus(`PDF loaded: ${numPages} pages. Starting processing queue (limit ${CONCURRENCY_LIMIT} parallel tasks)...`, true);

    const resultsFromPages: ExtractedTableData[] = [];
    let pageIndices = Array.from({ length: numPages }, (_, i) => i + 1); // Pages 1 to numPages

    // Function to process a single page
    const processSinglePage = async (pageNumber: number): Promise<ExtractedTableData | null> => {
        try {
            const page = await pdfDocument.getPage(pageNumber);
            const viewport = page.getViewport({ scale: 1.5 }); 
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            canvas.height = viewport.height;
            canvas.width = viewport.width;

            if (!context) {
                console.warn(`Skipping PDF page ${pageNumber} due to no canvas context.`);
                updateStatus(`Error: No canvas context for PDF page ${pageNumber}. Skipping.`, false);
                return null;
            }

            await page.render({ canvasContext: context, viewport: viewport }).promise;
            const imageDataUrl = canvas.toDataURL('image/png');
            const base64ImageData = imageDataUrl.split(',')[1];
            
            const tablesOnPage = await extractTablesFromImage(base64ImageData, pageNumber);
            if (tablesOnPage && tablesOnPage.length > 0) {
                return { pageNumber, tables: tablesOnPage };
            }
            return null;
        } catch (error) {
            console.error(`Error processing PDF page ${pageNumber}:`, error);
            if (!(error instanceof Error && (error.message.includes("AI error") || error.message.includes("AI blocked") || error.message.startsWith("AI ") || error.message.includes("API request failed")))) {
                 updateStatus(`Failed processing PDF page ${pageNumber}: ${error instanceof Error ? error.message : String(error)}.`, false);
            }
            return null; 
        }
    };

    // Concurrency management
    let activePromisesCount = 0;
    let promisesResolved = 0; 
    const totalTasks = pageIndices.length;

    const resultsPromise = new Promise<void>(resolveAllPages => {
        if (totalTasks === 0) {
            resolveAllPages();
            return;
        }
        const runNextTask = () => {
            if (promisesResolved === totalTasks && activePromisesCount === 0) {
                resolveAllPages();
                return;
            }

            while (activePromisesCount < CONCURRENCY_LIMIT && pageIndices.length > 0) {
                const pageNumToProcess = pageIndices.shift();
                if (pageNumToProcess === undefined) break;

                activePromisesCount++;
                updateStatus(`PDF: ${promisesResolved}/${totalTasks} pages complete. ${activePromisesCount} in progress, ${pageIndices.length + 1} queued...`, true);

                processSinglePage(pageNumToProcess)
                    .then(result => {
                        if (result) {
                            resultsFromPages.push(result);
                        }
                    })
                    .catch(error => { 
                        console.error(`Unhandled error for page ${pageNumToProcess} in concurrency runner:`, error);
                         updateStatus(`Critical error processing page ${pageNumToProcess}. Check console.`, false);
                    })
                    .finally(() => {
                        activePromisesCount--;
                        promisesResolved++;
                        
                        if (promisesResolved < totalTasks) {
                           updateStatus(`PDF: ${promisesResolved}/${totalTasks} pages complete. ${activePromisesCount} in progress, ${pageIndices.length} queued...`, true);
                        } else if (activePromisesCount > 0) {
                           updateStatus(`PDF: Completing final ${activePromisesCount} of ${totalTasks} pages...`, true);
                        }
                        runNextTask(); 
                    });
            }
             if (activePromisesCount === 0 && pageIndices.length > 0) { 
                 runNextTask(); 
            }
        };
        runNextTask(); 
    });

    await resultsPromise; 

    resultsFromPages.sort((a, b) => a.pageNumber - b.pageNumber);
    allExtractedTables.push(...resultsFromPages);
}


async function processImageFile(file: File) {
    updateStatus('Processing image file...', true);
    const reader = new FileReader();
    return new Promise<void>((resolve, reject) => {
        reader.onload = async (e) => {
            try {
                const imageDataUrl = e.target?.result as string;
                const base64ImageData = imageDataUrl.split(',')[1];
                updateStatus('Extracting tables from image with AI...', true);
                const tablesFromImage = await extractTablesFromImage(base64ImageData, 1); // Treat as page 1
                if (tablesFromImage && tablesFromImage.length > 0) {
                    allExtractedTables.push({ pageNumber: 1, tables: tablesFromImage, pageName: "Image" });
                }
                resolve();
            } catch (error) {
                reject(error);
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });
}

async function processWordFile(file: File) {
    updateStatus('Processing Word file with standard method...', true);
    const arrayBuffer = await file.arrayBuffer();

    try {
        // Attempt 1: Use mammoth.js (best for .docx and some .doc)
        updateStatus('Converting Word document to text...', true);
        const result = await mammoth.convertToHtml({ arrayBuffer: arrayBuffer });
        const htmlContent = result.value;
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = htmlContent;
        const textContent = tempDiv.textContent || tempDiv.innerText || "";

        if (textContent && textContent.trim()) {
            updateStatus('Extracting tables from Word content with AI...', true);
            const tablesFromText = await extractTablesFromText(textContent, 1);
            if (tablesFromText && tablesFromText.length > 0) {
                allExtractedTables.push({ pageNumber: 1, tables: tablesFromText, pageName: "Word Content" });
            }
        } else {
            console.warn('Word document appears to be empty after mammoth.js conversion. Trying fallback.');
            // This error will be caught and trigger the fallback
            throw new Error("Mammoth.js extracted no text.");
        }
    } catch (error) {
        console.warn("Standard Word processing failed:", error, "Attempting fallback using direct file analysis with AI.");
        updateStatus('Standard processing failed. Trying AI-based file analysis fallback...', true);
        
        // Fallback: Read file as base64 and send to Gemini for analysis
        const reader = new FileReader();
        return new Promise<void>((resolve, reject) => {
            reader.onload = async (e) => {
                try {
                    const fileDataUrl = e.target?.result as string;
                    const base64FileData = fileDataUrl.split(',')[1];
                    // Use the file's actual MIME type, or a generic one if unavailable.
                    const mimeType = file.type || 'application/msword';

                    updateStatus('Extracting tables directly from file data with AI...', true);
                    const tablesFromFile = await extractTablesFromBinary(base64FileData, mimeType, file.name, 1);
                    if (tablesFromFile && tablesFromFile.length > 0) {
                        allExtractedTables.push({ pageNumber: 1, tables: tablesFromFile, pageName: "Word (AI Fallback)" });
                    }
                    resolve();
                } catch (fallbackError) {
                    console.error("Fallback AI processing for Word file also failed:", fallbackError);
                    reject(new Error(`Failed to process Word file with both standard and AI fallback methods. Error: ${fallbackError instanceof Error ? fallbackError.message : String(fallbackError)}`));
                }
            };
            reader.onerror = (err) => {
                 console.error("FileReader error during fallback:", err);
                 reject(new Error('Failed to read file for AI fallback processing.'));
            };
            reader.readAsDataURL(file);
        });
    }
}


async function processExcelFile(file: File) {
    updateStatus('Processing Excel file...', true);
    const reader = new FileReader();
    return new Promise<void>((resolve, reject) => {
        reader.onload = (e) => {
            try {
                const data = e.target?.result;
                const workbook = XLSX.read(data, { type: 'array' });
                workbook.SheetNames.forEach((sheetName, index) => {
                    updateStatus(`Processing Excel sheet: ${sheetName}`, true);
                    const worksheet = workbook.Sheets[sheetName];
                    const jsonData: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: "" });
                    
                    const stringTableData: string[][] = jsonData.map(row => 
                        row.map(cell => String(cell === null || cell === undefined ? "" : cell))
                    );

                    if (stringTableData.length > 0 && stringTableData.some(row => row.length > 0 && row.some(cell => cell.trim() !== ""))) {
                        allExtractedTables.push({
                            pageNumber: index + 1,
                            pageName: sheetName,
                            tables: [stringTableData] 
                        });
                    }
                });
                resolve();
            } catch (error) {
                reject(error);
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsArrayBuffer(file);
    });
}

async function processJsonFile(file: File) {
    updateStatus('Processing JSON file...', true);
    const reader = new FileReader();
    return new Promise<void>((resolve, reject) => {
        reader.onload = (e) => {
            try {
                const text = e.target?.result as string;
                const parsedJson = JSON.parse(text);
                let tablesToPush: string[][][] = [];

                if (parsedJson.tables_on_page && Array.isArray(parsedJson.tables_on_page)) { 
                    tablesToPush = parsedJson.tables_on_page.filter((table: any) => Array.isArray(table));
                } else if (Array.isArray(parsedJson) && parsedJson.every(table => Array.isArray(table) && table.every((row:any) => Array.isArray(row)))) {
                    tablesToPush = parsedJson;
                } else if (Array.isArray(parsedJson) && parsedJson.length > 0 && typeof parsedJson[0] === 'object' && parsedJson[0] !== null && !Array.isArray(parsedJson[0])) {
                    const headers = Object.keys(parsedJson[0]);
                    const rows = parsedJson.map((obj: any) => headers.map(header => String(obj[header] !== undefined ? obj[header] : "")));
                    tablesToPush = [[headers, ...rows]];
                } else if (Array.isArray(parsedJson) && parsedJson.length === 0) { 
                     tablesToPush = [];
                }
                else {
                    updateStatus("Warning: JSON structure not recognized as simple tabular data. Trying to display as single cell.", false);
                    tablesToPush = [[ [ JSON.stringify(parsedJson, null, 2) ] ]]; 
                }
                
                if (tablesToPush.length > 0) {
                     allExtractedTables.push({ pageNumber: 1, tables: tablesToPush, pageName: "JSON Data" });
                }
                resolve();
            } catch (error) {
                console.error("Error parsing JSON file:", error)
                reject(new Error(`Invalid JSON file: ${error instanceof Error ? error.message : String(error)}`));
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsText(file);
    });
}

async function processCsvFile(file: File) {
    updateStatus('Processing CSV file...', true);
    const reader = new FileReader();
    return new Promise<void>((resolve, reject) => {
        reader.onload = (e) => {
            try {
                const text = e.target?.result as string;
                const workbook = XLSX.read(text, {type: 'string', raw: true });
                const firstSheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[firstSheetName];
                const jsonData: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: "" });
                
                const stringTableData: string[][] = jsonData.map(row => 
                    row.map(cell => String(cell === null || cell === undefined ? "" : cell))
                );

                if (stringTableData.length > 0 && stringTableData.some(row => row.length > 0 && row.some(cell => cell.trim() !== ""))) {
                    allExtractedTables.push({ pageNumber: 1, tables: [stringTableData], pageName: "CSV Data" });
                }
                resolve();
            } catch (error) {
                reject(error);
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsText(file);
    });
}

async function processTextFile(file: File) {
    updateStatus('Processing text file...', true);
    const reader = new FileReader();
    return new Promise<void>((resolve, reject) => {
        reader.onload = async (e) => {
            try {
                const textContent = e.target?.result as string;
                updateStatus('Extracting tables from text with AI...', true);
                const tablesFromText = await extractTablesFromText(textContent, 1); // Treat as page 1
                if (tablesFromText && tablesFromText.length > 0) {
                    allExtractedTables.push({ pageNumber: 1, tables: tablesFromText, pageName: "Text Content" });
                }
                resolve();
            } catch (error) {
                reject(error);
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsText(file);
    });
}

function isRetryableError(error: any): boolean {
    const errorMessage = String(error?.message || error).toLowerCase();
    // General network errors or 5xx server errors
    if (errorMessage.includes("network error") || 
        errorMessage.includes("rpc failed") || 
        errorMessage.includes("server error") ||
        errorMessage.includes("timeout") ||
        errorMessage.includes("too many requests") || 
        (error?.error?.code && Number(error.error.code) >= 500 && Number(error.error.code) < 600) || 
        (error?.error?.code && Number(error.error.code) === 429) || 
        (typeof error?.status === 'string' && error.status.toLowerCase() === 'unknown') || 
        (typeof error?.code === 'number' && ( (error.code >=500 && error.code < 600) || error.code === 429 )) || 
        errorMessage.includes("500 unknown") || 
        errorMessage.includes("http error 500") ||
        errorMessage.includes("http error 502") || 
        errorMessage.includes("http error 503") || 
        errorMessage.includes("http error 504")    
       ) {
        return true;
    }
    return false;
}

async function generateContentWithRetry(
    request: GenerateContentParameters,
    pageNum: number,
    fileType: 'image' | 'text' | 'binary file'
): Promise<GenerateContentResponse> {
    await ensureApiRateLimit(); 

    const MAX_RETRIES = 3;
    let retries = 0;
    let delay = 1000; 

    while (retries < MAX_RETRIES) {
        try {
            const response = await ai.models.generateContent(request);
            return response; 
        } catch (error: any) {
            retries++;
            if (retries >= MAX_RETRIES || !isRetryableError(error)) {
                console.error(`AI ${fileType} extraction failed for page ${pageNum} after ${retries} attempt(s). Error:`, error);
                if (isRetryableError(error) && retries >= MAX_RETRIES){
                     throw new Error(`API request failed after ${MAX_RETRIES} attempts for page ${pageNum} due to network/server issues. Original error: ${error.message || String(error)}`);
                }
                throw error; 
            }
            
            console.warn(`AI ${fileType} extraction attempt ${retries} failed for page ${pageNum} with retryable error. Retrying in ${delay / 1000}s... Error:`, error);
            updateStatus(`AI Warning (${fileType} page ${pageNum}): API request failed (attempt ${retries}/${MAX_RETRIES}). Retrying...`, true);
            await new Promise(resolve => setTimeout(resolve, delay));
            delay *= 2; 
            if (retries < MAX_RETRIES) { 
                await ensureApiRateLimit();
            }
        }
    }
    throw new Error(`AI ${fileType} extraction failed for page ${pageNum} after ${MAX_RETRIES} retries.`);
}


async function extractTablesFromBinary(base64FileData: string, mimeType: string, fileName: string, pageNum: number): Promise<string[][][]> {
    const fileType = 'binary file';
    let geminiResponse: GenerateContentResponse | null = null;
    let rawResponseTextForErrorLog: string | undefined = undefined;
    let stringAttemptedToParse: string = "";

    // New Strategy: Embed the Base64 data directly into a text prompt.
    // This bypasses the API's MIME type restrictions on file attachments.
    const prompt = `You are an expert data extraction system. The user has uploaded a file named "${fileName}" with MIME type "${mimeType}".
This file could not be parsed by standard client-side libraries, likely because it's a legacy format (e.g., a Word .doc file) or a complex document.
The file's content has been encoded as a Base64 string below.

Your task is to:
1. Decode the following Base64 string to get the original binary file data.
2. Analyze the binary data to understand the file's structure and extract all textual content.
3. From the extracted text, identify all distinct tables.
4. Convert each table into a structured format.
5. Return the result as a single JSON object. This JSON object MUST have a key 'tables_on_page'. The value of 'tables_on_page' must be an array of tables. Each table must be an array of rows, and each row an array of string cells.
Example: {"tables_on_page": [ [ ["Header1", "Header2"], ["Row1Cell1", "Row1Cell2"] ] ]}
If no tables are found, return {"tables_on_page": []}.

IMPORTANT: Your entire response must be ONLY the JSON object, with no surrounding text, explanations, markdown fences, or confirmation that you have decoded the file.

Base64 encoded file content:
${base64FileData}`;

    const requestParams: GenerateContentParameters = {
        model: 'gemini-2.5-flash',
        contents: prompt, // Send a single text prompt
        config: {
            responseMimeType: "application/json"
        }
    };

    const _processAndValidateParsedTableData = (parsedData: any, attemptDescription: string): string[][][] | null => {
        if (parsedData && parsedData.tables_on_page && Array.isArray(parsedData.tables_on_page)) {
            parsedData.tables_on_page.forEach((table: any, tableIndex: number) => {
                if (!Array.isArray(table) || !table.every((row: any) => Array.isArray(row) && row.every((cell: any) => typeof cell === 'string'))) {
                    console.warn(`Table ${tableIndex + 1} on page ${pageNum} from ${fileType} ${attemptDescription} has an unexpected structure or non-string cells:`, table);
                    if (Array.isArray(table)) {
                        for (let r = 0; r < table.length; r++) {
                            if (Array.isArray(table[r])) {
                                for (let c = 0; c < table[r].length; c++) {
                                    if (typeof table[r][c] !== 'string') {
                                        table[r][c] = String(table[r][c]);
                                    }
                                }
                            } else { table[r] = [String(table[r])]; }
                        }
                    }
                }
            });
            updateStatus(`AI (${fileType} page ${pageNum}): Tables extracted ${attemptDescription}.`, true);
            return parsedData.tables_on_page.filter((table: any) => Array.isArray(table) && table.every((row: any) => Array.isArray(row))) as string[][][];
        }
        console.warn(`AI ${fileType} table extraction for page ${pageNum} ${attemptDescription} returned unexpected JSON structure. Raw:`, rawResponseTextForErrorLog, `Attempted:`, stringAttemptedToParse);
        updateStatus(`AI Warning (${fileType} page ${pageNum}): Unexpected response structure from AI ${attemptDescription}.`, false);
        return null;
    };

    try {
        updateStatus(`AI (${fileType} page ${pageNum}): Calling Gemini...`, true);
        geminiResponse = await generateContentWithRetry(requestParams, pageNum, fileType);
        
        rawResponseTextForErrorLog = geminiResponse.text;
        let stringToParse = geminiResponse.text.trim();

        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const fenceMatch = stringToParse.match(fenceRegex);
        if (fenceMatch && fenceMatch[2]) {
            stringToParse = fenceMatch[2].trim();
        }
        const stringAfterFences = stringToParse;
        stringAttemptedToParse = stringAfterFences;

        try {
            const parsedData = JSON.parse(stringAfterFences);
            const tables = _processAndValidateParsedTableData(parsedData, "(attempt 1)");
            return tables ?? [];
        } catch (initialJsonError) {
            console.warn(`Initial JSON.parse of (fence-removed) content failed for ${fileType} page ${pageNum}. Error:`, initialJsonError);
            stringAttemptedToParse = stringAfterFences;

            if (stringAfterFences.startsWith("{") && stringAfterFences.endsWith("}")) {
                let openBraces = 0;
                let startIndex = -1;
                let objectFound = false;
                let cleanedString = stringAfterFences; 

                for (let i = 0; i < stringAfterFences.length; i++) {
                    if (stringAfterFences[i] === '{') {
                        if (startIndex === -1) startIndex = i;
                        openBraces++;
                    } else if (stringAfterFences[i] === '}') {
                        if (startIndex !== -1) {
                            openBraces--;
                            if (openBraces === 0) {
                                if (startIndex === 0) {
                                    cleanedString = stringAfterFences.substring(startIndex, i + 1);
                                    objectFound = true;
                                }
                                break; 
                            }
                        }
                    }
                }

                if (objectFound && openBraces === 0 && cleanedString !== stringAfterFences) {
                    console.warn(`Initial JSON.parse failed for ${fileType} page ${pageNum}. Attempting to parse extracted main object after cleanup. Original error for pre-cleanup:`, initialJsonError);
                    stringAttemptedToParse = cleanedString;
                    
                    const parsedDataAfterCleanup = JSON.parse(cleanedString);
                    const tables = _processAndValidateParsedTableData(parsedDataAfterCleanup, "after cleanup (attempt 2)");
                    return tables ?? [];
                } else {
                     if (objectFound && openBraces !==0) {
                        console.warn(`Attempted JSON cleanup for ${fileType} page ${pageNum}, but result was still unbalanced. Error for pre-cleanup:`, initialJsonError);
                    }
                    throw initialJsonError;
                }
            } else {
                throw initialJsonError;
            }
        }
    } catch (error) {
        console.error(`AI ${fileType} table extraction failed for page ${pageNum}. Raw API response (if any):`, rawResponseTextForErrorLog, `Attempted to parse:`, stringAttemptedToParse, `Error:`, error);
        let msg = `AI error (${fileType} page ${pageNum}): ${error instanceof Error ? error.message : String(error)}`;
        
        if (geminiResponse?.candidates?.[0]?.finishReason) {
             if (geminiResponse.candidates[0].finishReason === "SAFETY") { msg = `AI blocked (${fileType} page ${pageNum}) due to safety.`; }
             else if (geminiResponse.candidates[0].finishReason === "RECITATION") { msg = `AI blocked (${fileType} page ${pageNum}) due to recitation policy.`;}
             else if (geminiResponse.candidates[0].finishReason === "OTHER") { msg = `AI error (${fileType} page ${pageNum}): Model finished with reason OTHER.`; }
        } else if (error instanceof Error && (error.message.toLowerCase().includes("safety") || error.message.toLowerCase().includes("blocked"))) {
            msg = `AI blocked (${fileType} page ${pageNum}): ${error.message}`;
        }

        updateStatus(msg, false);
        let finalErrorMsg = msg;
        const originalStringAfterFencesOnError = (geminiResponse?.text.trim().match(/^```(\w*)?\s*\n?(.*?)\n?\s*```$/s)?.[2]?.trim() ?? geminiResponse?.text.trim());
        if (stringAttemptedToParse !== originalStringAfterFencesOnError) {
            finalErrorMsg += ` (after attempting JSON cleanup)`;
        }
        throw new Error(finalErrorMsg);
    }
}


async function extractTablesFromImage(base64ImageData: string, pageNum: number): Promise<string[][][]> {
    const fileType = 'image';
    let geminiResponse: GenerateContentResponse | null = null;
    let rawResponseTextForErrorLog: string | undefined = undefined; // For full context in logs
    let stringAttemptedToParse: string = ""; // What was actually passed to JSON.parse that failed

    const imagePart = { inlineData: { mimeType: 'image/png', data: base64ImageData } };
    const textPart = {
        text: `You are an expert table extraction system. Analyze the provided image of a document page.
Identify all distinct tables present. For each table found, extract its data.
Return the result as a JSON object. This JSON object MUST have a key 'tables_on_page'.
The value of 'tables_on_page' should be an array, where each element represents one table.
Each table itself should be an array of arrays, with inner arrays representing rows and their cell values (strings).
Example: {"tables_on_page": [ [ ["Header1", "Header2"], ["Row1Cell1", "Row1Cell2"] ], [ ["Product", "Price"], ["Apple", "$1"] ] ]}
If no tables are found on the page, return {"tables_on_page": []}.
IMPORTANT: The response should consist ONLY of this single JSON object. Do not include any additional text, explanations, or summaries before or after the JSON object.
All textual content from the document should be placed *within* the appropriate cell strings in the JSON, not as separate commentary.`
    };
    
    const requestParams: GenerateContentParameters = {
        model: 'gemini-2.5-flash',
        contents: { parts: [textPart, imagePart] },
        config: { responseMimeType: "application/json" }
    };

    // Helper to process parsed data, reducing duplication
    const _processAndValidateParsedTableData = (parsedData: any, attemptDescription: string): string[][][] | null => {
        if (parsedData && parsedData.tables_on_page && Array.isArray(parsedData.tables_on_page)) {
            parsedData.tables_on_page.forEach((table: any, tableIndex: number) => {
                if (!Array.isArray(table) || !table.every((row: any) => Array.isArray(row) && row.every((cell: any) => typeof cell === 'string'))) {
                    console.warn(`Table ${tableIndex + 1} on page ${pageNum} from ${fileType} ${attemptDescription} has an unexpected structure or non-string cells:`, table);
                    if (Array.isArray(table)) {
                        for (let r = 0; r < table.length; r++) {
                            if (Array.isArray(table[r])) {
                                for (let c = 0; c < table[r].length; c++) {
                                    if (typeof table[r][c] !== 'string') {
                                        table[r][c] = String(table[r][c]);
                                    }
                                }
                            } else { table[r] = [String(table[r])]; }
                        }
                    }
                }
            });
            updateStatus(`AI (${fileType} page ${pageNum}): Tables extracted ${attemptDescription}.`, true);
            return parsedData.tables_on_page.filter((table: any) => Array.isArray(table) && table.every((row: any) => Array.isArray(row))) as string[][][];
        }
        console.warn(`AI ${fileType} table extraction for page ${pageNum} ${attemptDescription} returned unexpected JSON structure. Raw:`, rawResponseTextForErrorLog, `Attempted:`, stringAttemptedToParse);
        updateStatus(`AI Warning (${fileType} page ${pageNum}): Unexpected response structure from AI ${attemptDescription}.`, false);
        return null; // Indicates unexpected structure
    };


    try {
        updateStatus(`AI (${fileType} page ${pageNum}): Calling Gemini...`, true);
        geminiResponse = await generateContentWithRetry(requestParams, pageNum, fileType);
        
        rawResponseTextForErrorLog = geminiResponse.text; // Keep original for logs
        let stringToParse = geminiResponse.text.trim();

        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const fenceMatch = stringToParse.match(fenceRegex);
        if (fenceMatch && fenceMatch[2]) {
            stringToParse = fenceMatch[2].trim();
        }
        const stringAfterFences = stringToParse; // This is the primary candidate for parsing
        stringAttemptedToParse = stringAfterFences; // Default for error logging

        try {
            // Attempt 1: Parse the string after standard fence removal
            const parsedData = JSON.parse(stringAfterFences);
            const tables = _processAndValidateParsedTableData(parsedData, "(attempt 1)");
            return tables ?? [];
        } catch (initialJsonError) {
            console.warn(`Initial JSON.parse of (fence-removed) content failed for ${fileType} page ${pageNum}. Error:`, initialJsonError);
            stringAttemptedToParse = stringAfterFences; // String that caused initialJsonError

            // Attempt 2: If initial parse fails, try secondary cleanup (extract outermost object)
            if (stringAfterFences.startsWith("{") && stringAfterFences.endsWith("}")) {
                let openBraces = 0;
                let startIndex = -1;
                let objectFound = false;
                let cleanedString = stringAfterFences; 

                for (let i = 0; i < stringAfterFences.length; i++) {
                    if (stringAfterFences[i] === '{') {
                        if (startIndex === -1) startIndex = i;
                        openBraces++;
                    } else if (stringAfterFences[i] === '}') {
                        if (startIndex !== -1) {
                            openBraces--;
                            if (openBraces === 0) {
                                if (startIndex === 0) { // Ensure object starts at the beginning
                                    cleanedString = stringAfterFences.substring(startIndex, i + 1);
                                    objectFound = true;
                                }
                                break; 
                            }
                        }
                    }
                }

                if (objectFound && openBraces === 0 && cleanedString !== stringAfterFences) {
                    console.warn(`Initial JSON.parse failed for ${fileType} page ${pageNum}. Attempting to parse extracted main object after cleanup. Original error for pre-cleanup:`, initialJsonError);
                    stringAttemptedToParse = cleanedString; // This is the string for the second parse attempt
                    
                    const parsedDataAfterCleanup = JSON.parse(cleanedString); // This can throw, will be caught by outer catch
                    const tables = _processAndValidateParsedTableData(parsedDataAfterCleanup, "after cleanup (attempt 2)");
                    return tables ?? [];
                } else {
                     if (objectFound && openBraces !==0) {
                        console.warn(`Attempted JSON cleanup for ${fileType} page ${pageNum}, but result was still unbalanced. Error for pre-cleanup:`, initialJsonError);
                    }
                    // Cleanup didn't change the string, or failed to produce a balanced object
                    throw initialJsonError; // Re-throw the original error
                }
            } else {
                // Did not start/end with "{}", so re-throw original error from first attempt
                throw initialJsonError;
            }
        }
    } catch (error) {
        console.error(`AI ${fileType} table extraction failed for page ${pageNum}. Raw API response (if any):`, rawResponseTextForErrorLog, `Attempted to parse:`, stringAttemptedToParse, `Error:`, error);
        let msg = `AI error (${fileType} page ${pageNum}): ${error instanceof Error ? error.message : String(error)}`;
        
        if (geminiResponse?.candidates?.[0]?.finishReason) {
             if (geminiResponse.candidates[0].finishReason === "SAFETY") { msg = `AI blocked (${fileType} page ${pageNum}) due to safety.`; }
             else if (geminiResponse.candidates[0].finishReason === "RECITATION") { msg = `AI blocked (${fileType} page ${pageNum}) due to recitation policy.`;}
             else if (geminiResponse.candidates[0].finishReason === "OTHER") { msg = `AI error (${fileType} page ${pageNum}): Model finished with reason OTHER.`; }
        } else if (error instanceof Error && (error.message.toLowerCase().includes("safety") || error.message.toLowerCase().includes("blocked"))) {
            msg = `AI blocked (${fileType} page ${pageNum}): ${error.message}`;
        }

        updateStatus(msg, false);
        let finalErrorMsg = msg;
        const originalStringAfterFencesOnError = (geminiResponse?.text.trim().match(/^```(\w*)?\s*\n?(.*?)\n?\s*```$/s)?.[2]?.trim() ?? geminiResponse?.text.trim());
        if (stringAttemptedToParse !== originalStringAfterFencesOnError) {
            finalErrorMsg += ` (after attempting JSON cleanup)`;
        }
        throw new Error(finalErrorMsg);
    }
}

async function extractTablesFromText(textContent: string, pageNum: number): Promise<string[][][]> {
    const fileType = 'text';
    let geminiResponse: GenerateContentResponse | null = null;
    let rawResponseTextForErrorLog: string | undefined = undefined;
    let stringAttemptedToParse: string = "";

    const systemInstruction = `You are an expert table extraction system.
Identify all distinct tables present in the provided text. For each table found, extract its data.
Return the result as a JSON object. This JSON object MUST have a key 'tables_on_page'.
The value of 'tables_on_page' should be an array, where each element represents one table.
Each table itself should be an array of arrays, with inner arrays representing rows and their cell values (strings).
Example: {"tables_on_page": [ [ ["Header1", "Header2"], ["Row1Cell1", "Row1Cell2"] ] ]}
If no tables are found, return {"tables_on_page": []}.
IMPORTANT: The response should consist ONLY of this single JSON object. Do not include any additional text, explanations, or summaries before or after the JSON object.
All textual content should be placed *within* the appropriate cell strings in the JSON, not as separate commentary. Infer headers if possible.`;

    const requestParams: GenerateContentParameters = {
        model: 'gemini-2.5-flash',
        contents: textContent,
        config: {
            systemInstruction: systemInstruction,
            responseMimeType: "application/json"
        }
    };
    
    // Helper to process parsed data, reducing duplication
    const _processAndValidateParsedTableData = (parsedData: any, attemptDescription: string): string[][][] | null => {
        if (parsedData && parsedData.tables_on_page && Array.isArray(parsedData.tables_on_page)) {
            parsedData.tables_on_page.forEach((table: any, tableIndex: number) => {
                if (!Array.isArray(table) || !table.every((row: any) => Array.isArray(row) && row.every((cell: any) => typeof cell === 'string'))) {
                     console.warn(`Table ${tableIndex + 1} on page ${pageNum} from ${fileType} ${attemptDescription} has an unexpected structure or non-string cells:`, table);
                    if (Array.isArray(table)) {
                        for (let r = 0; r < table.length; r++) {
                            if (Array.isArray(table[r])) {
                                for (let c = 0; c < table[r].length; c++) {
                                    if (typeof table[r][c] !== 'string') {
                                        table[r][c] = String(table[r][c]);
                                    }
                                }
                            } else { table[r] = [String(table[r])]; }
                        }
                    }
                }
            });
            updateStatus(`AI (${fileType} page ${pageNum}): Tables extracted ${attemptDescription}.`, true);
            return parsedData.tables_on_page.filter((table: any) => Array.isArray(table) && table.every((row: any) => Array.isArray(row))) as string[][][];
        }
        console.warn(`AI ${fileType} table extraction for page ${pageNum} ${attemptDescription} returned unexpected JSON structure. Raw:`, rawResponseTextForErrorLog, `Attempted:`, stringAttemptedToParse );
        updateStatus(`AI Warning (${fileType} page ${pageNum}): Unexpected response structure from AI ${attemptDescription}.`, false);
        return null; // Indicates unexpected structure
    };

    try {
        updateStatus(`AI (${fileType} page ${pageNum}): Calling Gemini...`, true);
        geminiResponse = await generateContentWithRetry(requestParams, pageNum, fileType);

        rawResponseTextForErrorLog = geminiResponse.text;
        let stringToParse = geminiResponse.text.trim();

        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; // Define fenceRegex here
        const fenceMatch = stringToParse.match(fenceRegex);
        if (fenceMatch && fenceMatch[2]) {
            stringToParse = fenceMatch[2].trim();
        }
        const stringAfterFences = stringToParse;
        stringAttemptedToParse = stringAfterFences;


        try {
            // Attempt 1: Parse the string after standard fence removal
            const parsedData = JSON.parse(stringAfterFences);
            const tables = _processAndValidateParsedTableData(parsedData, "(attempt 1)");
            return tables ?? [];
        } catch (initialJsonError) {
            console.warn(`Initial JSON.parse of (fence-removed) content failed for ${fileType} page ${pageNum}. Error:`, initialJsonError);
            stringAttemptedToParse = stringAfterFences;

            // Attempt 2: If initial parse fails, try secondary cleanup
            if (stringAfterFences.startsWith("{") && stringAfterFences.endsWith("}")) {
                let openBraces = 0;
                let startIndex = -1;
                let objectFound = false;
                let cleanedString = stringAfterFences;

                for (let i = 0; i < stringAfterFences.length; i++) {
                    if (stringAfterFences[i] === '{') {
                        if (startIndex === -1) startIndex = i;
                        openBraces++;
                    } else if (stringAfterFences[i] === '}') {
                        if (startIndex !== -1) {
                            openBraces--;
                            if (openBraces === 0) {
                                if (startIndex === 0) {
                                    cleanedString = stringAfterFences.substring(startIndex, i + 1);
                                    objectFound = true;
                                }
                                break;
                            }
                        }
                    }
                }

                if (objectFound && openBraces === 0 && cleanedString !== stringAfterFences) {
                    console.warn(`Initial JSON.parse failed for ${fileType} page ${pageNum}. Attempting to parse extracted main object after cleanup. Original error for pre-cleanup:`, initialJsonError);
                    stringAttemptedToParse = cleanedString;
                    
                    const parsedDataAfterCleanup = JSON.parse(cleanedString);
                    const tables = _processAndValidateParsedTableData(parsedDataAfterCleanup, "after cleanup (attempt 2)");
                    return tables ?? [];
                } else {
                     if (objectFound && openBraces !==0) {
                         console.warn(`Attempted JSON cleanup for ${fileType} page ${pageNum}, but result was still unbalanced. Error for pre-cleanup:`, initialJsonError);
                    }
                    throw initialJsonError;
                }
            } else {
                throw initialJsonError;
            }
        }
    } catch (error) {
        console.error(`AI ${fileType} table extraction failed for page ${pageNum}. Raw API response (if any):`, rawResponseTextForErrorLog, `Attempted to parse:`, stringAttemptedToParse, `Error:`, error);
        let msg = `AI error (${fileType} page ${pageNum}): ${error instanceof Error ? error.message : String(error)}`;
        
        if (geminiResponse?.candidates?.[0]?.finishReason) {
            // ... (safety/recitation/other reasons handling) ...
             if (geminiResponse.candidates[0].finishReason === "SAFETY") { msg = `AI blocked (${fileType} page ${pageNum}) due to safety.`; }
             else if (geminiResponse.candidates[0].finishReason === "RECITATION") { msg = `AI blocked (${fileType} page ${pageNum}) due to recitation policy.`;}
             else if (geminiResponse.candidates[0].finishReason === "OTHER") { msg = `AI error (${fileType} page ${pageNum}): Model finished with reason OTHER.`; }
        } else if (error instanceof Error && (error.message.toLowerCase().includes("safety") || error.message.toLowerCase().includes("blocked"))) {
            msg = `AI blocked (${fileType} page ${pageNum}): ${error.message}`;
        }

        updateStatus(msg, false);
        let finalErrorMsg = msg;
        const originalStringAfterFencesOnError = (geminiResponse?.text.trim().match(/^```(\w*)?\s*\n?(.*?)\n?\s*```$/s)?.[2]?.trim() ?? geminiResponse?.text.trim());
        if (stringAttemptedToParse !== originalStringAfterFencesOnError) {
            finalErrorMsg += ` (after attempting JSON cleanup)`;
        }
        throw new Error(finalErrorMsg);
    }
}

function displayExtractedTables() {
    tablesOutput.innerHTML = ''; 

    if (allExtractedTables.length === 0) {
        tablesOutput.innerHTML = '<p>No tables found or extracted from the file.</p>';
        return;
    }

    allExtractedTables.forEach(pageData => {
        const pageContainer = document.createElement('div');
        pageContainer.className = 'page-container';
        
        const pageHeader = document.createElement('h3');
        pageHeader.textContent = pageData.pageName ? `Page ${pageData.pageNumber} (${pageData.pageName})` : `Page ${pageData.pageNumber}`;
        pageContainer.appendChild(pageHeader);

        if (pageData.tables.length === 0) {
            const noTablesMessage = document.createElement('p');
            noTablesMessage.textContent = 'No tables found on this page.';
            pageContainer.appendChild(noTablesMessage);
        } else {
            pageData.tables.forEach((tableData, tableIndex) => {
                const tableWrapper = document.createElement('div');
                tableWrapper.className = 'table-wrapper';

                const tableHeaderEl = document.createElement('h4');
                tableHeaderEl.textContent = `Table ${tableIndex + 1}`;
                tableWrapper.appendChild(tableHeaderEl);

                const tableElement = document.createElement('table');
                const tableHead = document.createElement('thead');
                const tableBody = document.createElement('tbody');

                const currentTablePageNum = pageData.pageNumber;
                const currentTableIndexOnPage = tableIndex;
                const currentTableColumnCount = (tableData.length > 0 && tableData[0]) ? tableData[0].length : 0;

                tableData.forEach((row, rowIndex) => {
                    const tr = document.createElement('tr');
                    const isHeaderRow = rowIndex === 0 && tableData.length > 1 && currentTableColumnCount > 0;

                    row.forEach((cellText, colIndex) => {
                        let cell: HTMLTableCellElement;
                        const headerTextContent = cellText || `Column ${colIndex + 1}`;

                        if (isHeaderRow) {
                            cell = document.createElement('th');
                            const checkbox = document.createElement('input');
                            checkbox.type = 'checkbox';
                            checkbox.className = 'column-select-checkbox';
                            checkbox.dataset.pageIdx = String(currentTablePageNum);
                            checkbox.dataset.tableIdx = String(currentTableIndexOnPage);
                            checkbox.dataset.colIdx = String(colIndex);
                            checkbox.setAttribute('aria-label', `Select column "${headerTextContent}" (Table ${tableIndex + 1}, Page ${currentTablePageNum})`);

                            let isThisTableTheGlobalSource = false;
                            if (globalFilterSourceInfo &&
                                currentTablePageNum === globalFilterSourceInfo.pageNumber &&
                                currentTableIndexOnPage === globalFilterSourceInfo.tableIndexOnPage) {
                                isThisTableTheGlobalSource = true;
                            }

                            if (globalFilterSourceInfo === null && currentTableColumnCount > 0) {
                                globalFilterSourceInfo = {
                                    pageNumber: currentTablePageNum,
                                    tableIndexOnPage: currentTableIndexOnPage,
                                    columnCount: currentTableColumnCount,
                                };
                                globalColumnSelections = Array(currentTableColumnCount).fill(true);
                                isThisTableTheGlobalSource = true;
                                tableElement.classList.add('global-filter-source-table');
                                filterInfoMessage.style.display = 'block';
                            }

                            if (isThisTableTheGlobalSource) {
                                checkbox.checked = globalColumnSelections[colIndex];
                                checkbox.disabled = false; 
                                checkbox.addEventListener('change', (e) => {
                                    const targetCheckbox = e.target as HTMLInputElement;
                                    const changedColIdx = parseInt(targetCheckbox.dataset.colIdx!, 10);
                                    if (globalFilterSourceInfo && globalColumnSelections.length === globalFilterSourceInfo.columnCount) {
                                        globalColumnSelections[changedColIdx] = targetCheckbox.checked;
                                        refreshDisplayedTableCheckboxes(); 
                                    }
                                });
                            } else if (globalFilterSourceInfo && currentTableColumnCount === globalFilterSourceInfo.columnCount) {
                                checkbox.checked = globalColumnSelections[colIndex];
                                checkbox.disabled = true;
                            } else { 
                                checkbox.checked = true; 
                                checkbox.disabled = false; 
                            }

                            const label = document.createElement('label');
                            label.appendChild(checkbox);
                            const span = document.createElement('span');
                            span.textContent = headerTextContent;
                            label.appendChild(span);
                            cell.appendChild(label);
                        } else {
                            cell = document.createElement('td');
                            cell.textContent = cellText;
                        }
                        tr.appendChild(cell);
                    });

                    if (isHeaderRow) {
                        tableHead.appendChild(tr);
                    } else {
                        tableBody.appendChild(tr);
                    }
                });
                
                if (tableHead.hasChildNodes()) tableElement.appendChild(tableHead);
                tableElement.appendChild(tableBody);
                tableWrapper.appendChild(tableElement);
                pageContainer.appendChild(tableWrapper);
            });
        }
        tablesOutput.appendChild(pageContainer);
    });
     refreshDisplayedTableCheckboxes(); 
}

function refreshDisplayedTableCheckboxes() {
    if (!globalFilterSourceInfo) return;

    const sourceInfo = globalFilterSourceInfo;

    document.querySelectorAll('.table-wrapper').forEach(tableWrapper => {
        const tableEl = tableWrapper.querySelector('table');
        if (!tableEl) return;

        const firstCheckboxInTable = tableEl.querySelector<HTMLInputElement>('thead .column-select-checkbox');
        if (!firstCheckboxInTable || !firstCheckboxInTable.dataset.pageIdx || !firstCheckboxInTable.dataset.tableIdx) {
            tableEl.classList.remove('global-filter-source-table');
             tableEl.querySelectorAll<HTMLInputElement>('thead .column-select-checkbox').forEach(cb => cb.disabled = false);
            return;
        }

        const pageNum = parseInt(firstCheckboxInTable.dataset.pageIdx, 10);
        const tableIdxOnPage = parseInt(firstCheckboxInTable.dataset.tableIdx, 10);
        
        const headerCells = tableEl.querySelectorAll('thead th');
        const columnCount = headerCells.length;

        const isThisTableTheSource = pageNum === sourceInfo.pageNumber && tableIdxOnPage === sourceInfo.tableIndexOnPage;
        tableEl.classList.toggle('global-filter-source-table', isThisTableTheSource);


        if (isThisTableTheSource) { 
             headerCells.forEach((th, colIdx) => {
                const cb = th.querySelector<HTMLInputElement>('.column-select-checkbox');
                if (cb && colIdx < globalColumnSelections.length) { 
                    cb.checked = globalColumnSelections[colIdx];
                    cb.disabled = false; 
                }
            });
        } else if (columnCount === sourceInfo.columnCount) { 
            headerCells.forEach((th, colIdx) => {
                const cb = th.querySelector<HTMLInputElement>('.column-select-checkbox');
                 if (cb && colIdx < globalColumnSelections.length) {
                    cb.checked = globalColumnSelections[colIdx];
                    cb.disabled = true;
                }
            });
        } else { 
             headerCells.forEach((th, colIdx) => {
                const cb = th.querySelector<HTMLInputElement>('.column-select-checkbox');
                if (cb) {
                    cb.disabled = false; 
                }
            });
        }
    });
}


function downloadExcel() {
    if (allExtractedTables.length === 0 || !allExtractedTables.some(pd => pd.tables.length > 0)) {
        updateStatus('No tables to download.', false);
        return;
    }

    updateStatus('Generating Excel file...', true);
    try {
        const workbook = XLSX.utils.book_new();

        allExtractedTables.forEach(pageData => {
            if (pageData.tables.length === 0) return;

            let sheetDataForPage: string[][] = [];
            let tablesAddedToSheet = 0;

            pageData.tables.forEach((currentTableData, tableIdxOnPage) => {
                if (currentTableData.length === 0) return;

                let filteredTableContent: string[][] = [];
                let specialMessageForTable: string | null = null;
                
                let headerRowElement: HTMLTableRowElement | null = null;
                const pageContainers = document.querySelectorAll<HTMLDivElement>('div.page-container');
                for (const container of Array.from(pageContainers)) {
                    const h3 = container.querySelector<HTMLHeadingElement>('h3');
                    const expectedPageHeaderText = pageData.pageName ?
                        `Page ${pageData.pageNumber} (${pageData.pageName})` :
                        `Page ${pageData.pageNumber}`;

                    if (h3 && h3.textContent && h3.textContent.trim() === expectedPageHeaderText) {
                        const tableWrapper = container.querySelector<HTMLDivElement>(`div.table-wrapper:nth-of-type(${tableIdxOnPage + 1})`);
                        if (tableWrapper) {
                            headerRowElement = tableWrapper.querySelector<HTMLTableRowElement>('table thead tr');
                        }
                        break; 
                    }
                }
                
                const isHeaderRowPresentForSelectionLogic = headerRowElement && currentTableData.length > 0 && currentTableData[0].length > 0;
                const currentTableColumnCount = isHeaderRowPresentForSelectionLogic ? currentTableData[0].length : 0;


                if (isHeaderRowPresentForSelectionLogic) {
                    const selectedColumnIndices: number[] = [];
                     currentTableData[0].forEach((_, colIdx) => { 
                        let checkbox = document.querySelector<HTMLInputElement>(
                            `input.column-select-checkbox[data-page-idx="${pageData.pageNumber}"][data-table-idx="${tableIdxOnPage}"][data-col-idx="${colIdx}"]`
                        );

                        if (checkbox) { 
                            if (checkbox.checked) {
                                selectedColumnIndices.push(colIdx);
                            }
                        } else if (globalFilterSourceInfo && currentTableColumnCount === globalFilterSourceInfo.columnCount && colIdx < globalColumnSelections.length) {
                            if (globalColumnSelections[colIdx]) {
                                selectedColumnIndices.push(colIdx);
                            }
                        } else if (!globalFilterSourceInfo) { 
                             selectedColumnIndices.push(colIdx);
                        }
                        else if (globalFilterSourceInfo && currentTableColumnCount !== globalFilterSourceInfo.columnCount) {
                             selectedColumnIndices.push(colIdx);
                        }
                    });

                    if (selectedColumnIndices.length > 0) {
                        filteredTableContent = currentTableData.map(row =>
                            selectedColumnIndices.map(idx => (row[idx] !== undefined ? String(row[idx]) : ""))
                        );
                    } else {
                        filteredTableContent = []; 
                        specialMessageForTable = "No columns selected for this table.";
                    }
                } else { 
                     filteredTableContent = currentTableData.map(row => row.map(cell => String(cell)));
                }
                
                if (tablesAddedToSheet > 0 && sheetDataForPage.length > 0) sheetDataForPage.push([]); 

                const tableTitle = pageData.pageName ?
                    `Table ${tableIdxOnPage + 1} (Page ${pageData.pageNumber} - ${pageData.pageName})` :
                    `Table ${tableIdxOnPage + 1} (Page ${pageData.pageNumber})`;
                sheetDataForPage.push([tableTitle]); 

                if (specialMessageForTable) {
                    sheetDataForPage.push([specialMessageForTable]);
                } else if (filteredTableContent.length > 0) {
                    sheetDataForPage.push(...filteredTableContent);
                } else {
                    sheetDataForPage.push(["Table is empty or all columns were filtered out."]);
                }
                tablesAddedToSheet++;
            });

            if (sheetDataForPage.length > 0) {
                const worksheet = XLSX.utils.aoa_to_sheet(sheetDataForPage);
                const colWidths = sheetDataForPage.reduce((acc: {wch: number}[], row) => {
                    row.forEach((cell, i) => {
                        const len = cell ? String(cell).length : 0;
                        const currentWidth = Math.max(len, 10); 
                        if (!acc[i] || acc[i].wch < currentWidth) acc[i] = { wch: currentWidth };
                    });
                    return acc;
                }, []);
                worksheet['!cols'] = colWidths.length > 0 ? colWidths : [{wch: 10}];

                let baseSheetName = pageData.pageName ? `${pageData.pageName}` : `P${pageData.pageNumber}`;
                baseSheetName = baseSheetName.replace(/[\*\?\:\[\]\\\/]/g, '_').substring(0, 25); 
                let finalSheetName = baseSheetName;
                let suffix = 1;
                while (workbook.SheetNames.includes(finalSheetName) && suffix < 100) { 
                    const suffixStr = `_${suffix}`;
                    finalSheetName = `${baseSheetName.substring(0, 31 - suffixStr.length)}${suffixStr}`;
                    suffix++;
                }
                 if (workbook.SheetNames.includes(finalSheetName)) { 
                    finalSheetName = `Sheet_${Date.now()}`.substring(0,31);
                }
                XLSX.utils.book_append_sheet(workbook, worksheet, finalSheetName);
            }
        });
        
        if (Object.keys(workbook.Sheets).length === 0) {
            updateStatus('No data to include in Excel. Check table content or column selections.', false);
            return;
        }

        XLSX.writeFile(workbook, 'extracted_tables.xlsx');
        updateStatus('Excel file generated and download started.', false);
    } catch (error) {
        console.error("Error generating Excel:", error);
        updateStatus(`Error generating Excel: ${error instanceof Error ? error.message : String(error)}`, false);
    }
}

function initializeApp() {
    // Attach event listeners
    fileUploadInput.addEventListener('change', handleFileSelect);
    downloadExcelButton.addEventListener('click', downloadExcel);

    // Set initial UI state
    updateStatus('Please select a file to begin (PDF, Image, Word, Excel, JSON, CSV, TXT).', false);
    fileNameDisplay.textContent = 'No file selected';
    downloadExcelButton.disabled = true;
    filterInfoMessage.style.display = 'none';

    console.log("File Table Extractor initialized. Waiting for file upload.");
}

initializeApp();